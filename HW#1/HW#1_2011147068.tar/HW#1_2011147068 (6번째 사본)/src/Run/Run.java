package Run;
import InputData.*;
import java.io.*;
import OutputData.*;
import List.*;

class Solve{
	private Input inData;
	private Output outData;
	public Solve(Input inData, Output outData){
		this.inData = inData;
		this.outData = outData;
	}
	public void check(){
		Dictionary dic = inData.getDict();
		for(int row = 0 ; row != inData.getDim(); ++row){
			for(int col = 0 ; col != inData.getDim(); ++col){
				char c = inData.getCharTable().get(row, col);
				Node<KeySet> target = dic.search(c);
				if(target == null)continue;
				List<Item> ws = target.getData().getWordSet();
				//현재위치를 해당 단어 set에 대해서 검색을 시킨다. 그 결과를 outData에 넣는다 
				check(row, col, ws);
				
			}
		}
	}
	public void check(int row, int col, List<Item> ws){
		//현재 위치에서, word set의 하나하나 단어들에 대해 조사를 수행한다.
		// 만약 현재위치에서 해가 나온다면 outData에 바로 update를 한다.
		// 해답이 없다면 그냥 넘어간다. 끝까지 들어있지 않다면 -1,-1로 항상 남아있기 떄문에 
		// 해당 단어가 없다는 것을 알 수 있다.
		if(!ws.isEmpty()){
			
		
			Node<Item> before = null; // Table에서 찾은거, wordset에서 지우기 위해서 
			
			for(Node<Item> i = ws.getHead(); i != null; i = i.getNext()){
				Item target = i.getData();
				//target word에 대해서 조사를 수행한다. 
				// 조사 결과 있다면 output에 결과를 넣고, ws에서 해당 String에 해당하는 Item을 지워준다.
				if(check(row, col, target)){
					if(before == null){
						//지워야되는게 첫번째노드인 경우
						Node<Item> temp = new Node<Item>();
						temp.setNext(i.getNext());
						ws.deleteFront();
						i = temp;
						if(i==null) break; // 제일 마지막 node를 지웠을 경우는 바로 나가야된다.
						
					}
					else{
						ws.delete(before);
						i = before.getNext();
						if(i==null) break; // 제일 마지막 node를 지웠을 경우는 바로 나가야된다.
						
						
					}
	
				}
				else before = i ;
			}
		}
	}
	public boolean check(int row, int col, Item target){
		//현재위치에서 해당 target word에 대해 조사를 수행한다.
		Point end = getEndPoint(row, col, target.getString());
		
		if(!end.is_null()){
			//System.out.println("Asdfasdfsaf");
			//endPoint가 존재한다면
			/*dictionary의 몇 번째 단어인지를 찾아, end POint를 넣는다.
			그 이후, 해당 word set에서 삭제를 수행한다. -> 이건 밖에서
			*/
			int index = target.getOrder();
			outData.putAnswer(index, new Point(row, col), end);
			
			return true;
		}
		return false;//현재 위치에서 target에 대해 check를 했을 때 답이 없는 경우
		
	}
	public Point getEndPoint(int row, int col, String word){
		/*
		 * 성공하면 값이 들어있는 POint를 return
		 * 실패하면 (-1, -1)을 리턴
		 */
		Point end = new Point();

		
		for(int code = 0 ; code != 8 ; ++code){
			System.out.println(code);		
			Point t = this.getEndPoint(row, col, word, code);
			if(t.getX() != -1){
				end.setX(t.getX());
				end.setY(t.getY());
				break;
				
			}

		}

		return end;
	}
	public Point getEndPoint(int row, int col, String word, int code){
		Point result =  new Point();
		Point temp = new Point();
		String target = inData.getCharTable().extractWord(row, col, 
				word.length(), code, temp, inData.getDim());
		if(word.equals(target))
			return temp;
		return result;
		
	}
	
	
	
	
}

public class Run {
	public static void main(String[] args)
			throws IOException{
		
		BufferedReader br = new BufferedReader
				(new FileReader("input.txt"));
			Input inputData = new Input();
			inputData.putInput(br);
			inputData.print();
			Output outputData = new Output(inputData.getDicnum());
			Solve solve = new Solve(inputData, outputData);
			solve.check();
			
			outputData.print();
			
		}


		

}
