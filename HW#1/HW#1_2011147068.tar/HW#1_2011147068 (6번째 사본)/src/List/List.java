package List;

public class List<T>{
	private Node<T> head;

	private int size;
	public List(){
		head = null;
		size = 0;
	}
	public int getSize(){
		return size;
	}
	public void insertFront(T data){
		head = new Node<T>(data, head);
		++size;
	}
	public boolean isEmpty(){return size == 0 ;}
	
	
	//single이면서 지우는 방법을 찾기 위해 두개를 만든거.
	public void deleteFront(){
		if(size != 0){
			head = head.getNext();
			--size;
		}
	}
	public void delete(Node<T> beforeDiscard){
		//head 지울때는 다른걸 써야됨.
		if(size != 0){
			beforeDiscard.setNext(beforeDiscard.getNext().getNext());
			size--;
			if(size == 0) head = null;
		}
	}
	public Node<T> getHead(){
		return head;
	}
	

}
