package List;

public class Node<T>{
	private T data;
	private Node next;
	public Node(){
		setData(null);
		setNext(null);
	}
	public Node(T data){
		this.setData(data);
		this.setNext(null);
	}
	public Node(T data, Node next){
		this.setData(data);
		this.setNext(next);
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public Node getNext() {
		return next;
	}
	public void setNext(Node next) {
		this.next = next;
	}
	
	

}
