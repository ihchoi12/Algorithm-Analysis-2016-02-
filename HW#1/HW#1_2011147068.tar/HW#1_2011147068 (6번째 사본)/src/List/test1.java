package List;

public class test1 {

	public static void print(List<String> li){
		for(Node<String> i = li.getHead(); i != null; i = i.getNext()){
			System.out.print(i.getData()+" ");
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> test = new List<String>();
		Node<String> as = new Node<String>("abc");
		test.insertFront("a");
		test.insertFront("b");
		test.insertFront("c");
		test.insertFront("d");
		test.insertFront("e");
		test.insertFront("f");
		test.insertFront("g");
		test.delete(test.getHead());
		test.delete(test.getHead());
		test.deleteFront();		
		System.out.println(test.getSize());
		print(test);
	}
	

}
