package InputData;

public class Item{
	private String word;
	private int order; 
	public Item(String word, int order){
		this.word = word;
		this.order = order;
	}
	public String getString(){
		return word;
	}
	public int getOrder(){
		return order;
	}

	public Item(){
		word = "\0";
		order = 0;
	}
	public void print(){
		System.out.print(word);
		System.out.print(order);

	}
}