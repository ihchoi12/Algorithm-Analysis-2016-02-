package InputData;

import List.*;
public class Dictionary {
	private List<KeySet> dict;
	//private Node<KeySet> cursor;
	private int dictnum;
	public Dictionary(){
		dict = new List<KeySet>();
		dictnum = 0;
	}
	
	public List<KeySet> getDict(){
		return dict;
	}
	public void inc_dictnum(){
		dictnum++;
	}
	public void create_KeySet(String newString, int order){
		//newString을 담은 새로운 KeySet을 dict에 추가한다.
		++dictnum;
		if(dict == null) dict = new List<KeySet>();

		dict.insertFront(new KeySet(newString, order));
	}
	public Node<KeySet> search(char c){
		
		for(Node<KeySet> i = dict.getHead(); i != null; i = i.getNext()){
			List<Item> temp = i.getData().getWordSet();
			if(temp.getHead() != null){
				char target = temp.getHead().getData().getString().charAt(0);
				if(c == target) return i;				
			}
		}
		return null;
	}
	public void print(){
		for(Node<KeySet> i = dict.getHead(); i != null; i = i.getNext()){
			i.getData().print();
			System.out.println();
		}
	}

}
