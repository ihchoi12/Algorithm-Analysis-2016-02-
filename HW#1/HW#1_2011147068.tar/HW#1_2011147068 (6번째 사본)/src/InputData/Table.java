package InputData;
import OutputData.*;
public class Table {
	private int dim;
	private char[][] Matrix;
	
	public Table(int dim){
		this.dim = dim;
		Matrix = new char[dim][];
		for(int i = 0; i != dim ; ++i)
			Matrix[i] = new char[dim];		
	}
	public int getDim(){
		return dim;
	}
	
	public void set_val_by_index(int row, int col, char c){
		Matrix[row][col] = c;
	}
	public char[][] getMatrix(){
		return Matrix;
	}
	public char get(int row, int col){
		return Matrix[row][col];
	}
	public void print(){
		for(int row = 0; row != dim; ++row){
			for(int col = 0 ; col != dim; ++col){
				System.out.print(Matrix[row][col]);
			}
			System.out.println();
		}
	}
	public String extractWord(int row, int col, int length, int code, Point temp, int dim){
		String target = new String();
		int l = 0;
		switch(code){
		case(0):
			for(int i = 0 ; i != length; ++i){
				target +=String.valueOf(this.get(row, col--));
				if(length -1 == i) ++col;
				if(col < 0 )col += dim;
				
			}
			temp.setX(row);temp.setY(col);	
			return target;
			
		case(1):
			//length, row, col
			while(true){
				if((-1<row && row <dim) && (-1<col && col <dim)){
					//boundary 안
					if(l == length){
						row +=1; col +=1;
						break;//만들어진 단어길이가 length와 같은가
					}
					else{
						target += String.valueOf(Matrix[row][col]);
						l++;
						row -=1; col -=1;
					}
				}
				else{
					row += 1; col += 1;
					int oldrow = row;
					row = (dim-1) - col;
					col = (dim-1) - oldrow;
					
				}
			}
			
			
			temp.setX(row);temp.setY(col); 
			return target;
		case(2):
			for(int i = 0 ; i != length; ++i){	
				target +=String.valueOf(this.get(row--, col));
				if(length -1 == i) ++row;
				if(row < 0 ) row += dim;
				
			}
			temp.setX(row);temp.setY(col); 
			return target;
		case(3):
			while(true){
				if((-1<row && row <dim) && (-1<col && col <dim)){
					//boundary 안
					if(l == length){
						row+=1; col -= 1;
						break;//만들어진 단어길이가 length와 같은가
					}
					else{
						target += String.valueOf(Matrix[row][col]);
						l++;
						row -=1; col +=1;
					}
				}
				else{
					row += 1; col -= 1;
					int t = col;
					col = row;
					row = t;
				}
			}
			
			
			temp.setX(row);temp.setY(col); 
			return target;
		
		case(4):
			for(int i = 0 ; i != length; ++i){
				target +=String.valueOf(this.get(row, col++));
				if(length -1 == i) --col;	
				if(col > dim-1 )col -= dim;
					
				}
				temp.setX(row);
				temp.setY(col); 
				return target;


		case(5):
			//length, row, col
			while(true){
				if((-1<row && row <dim) && (-1<col && col <dim)){
					//boundary 안
					if(l == length){
						row -= 1; col -= 1;
						break;//만들어진 단어길이가 length와 같은가
					}
					else{
						target += String.valueOf(Matrix[row][col]);
						l++;
						row +=1; col +=1;
					}
				}
				else{
					row -= 1; col -= 1;
					int oldrow = row;
					row = (dim-1) - col;
					col = (dim-1) - oldrow;
					
				}
			}
			
			
			temp.setX(row);temp.setY(col); 
			return target;
		case(6):
			for(int i = 0 ; i != length; ++i){
				target +=String.valueOf(this.get(row++, col));
				if(length -1 == i) --row;
				if(row > dim-1 )row -= dim;
			}
			System.out.print(target);
			temp.setX(row);
			temp.setY(col); 
			return target;
		case(7):
			while(true){
				if((-1<row && row <dim) && (-1<col && col <dim)){
					//boundary 안
					if(l == length){
						row +=1; col -= 1;
						break;//만들어진 단어길이가 length와 같은가
					}
					else{
						target += String.valueOf(Matrix[row][col]);
						l++;
						row +=1; col -=1;
					}
				}
				else{
					row -= 1; col += 1;
					int t = col;
					col = row;
					row = t;
				}
			}
		temp.setX(row);temp.setY(col); 
		return target;
		default:
			return new String("Error");	
		}
	}
	
}
