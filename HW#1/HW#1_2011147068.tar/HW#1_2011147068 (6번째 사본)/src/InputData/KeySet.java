package InputData;
import List.*;

public class KeySet {
	private List<Item> itemSet;
	private int num;
	
	public KeySet(){
		num = 0;
		itemSet = new List<Item>();
	}
	public KeySet(String newString, int order){
		num = 1;
		itemSet = new List<Item>();
		itemSet.insertFront(new Item(newString, order));
	}
	public void create_KeySet(String word, int order){
		itemSet.insertFront(new Item(word, order));
		++num;
	}
	public void add(String word, int order){
		itemSet.insertFront(new Item(word, order));
		++num;
	}
	public List<Item> getWordSet(){
		return itemSet;
	}
	public void print(){
		for(Node<Item> i = itemSet.getHead(); i != null; i = i.getNext()){
			i.getData().print();
		}
	}


}
