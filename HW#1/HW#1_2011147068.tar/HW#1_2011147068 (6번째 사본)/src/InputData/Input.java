package InputData;
import java.io.*;

public class Input {
	private BufferedReader br;
	private int dim;
	private int dicnum;
	
	private Table charTable;
	private Dictionary dict;
	
	
	public Input(){
	}
	public void putInput(BufferedReader br) throws IOException{
		this.br = br;
		String line_first = br.readLine();

		String[] temp = line_first.split(" ");
		this.setDim(Integer.parseInt(temp[0]));
		this.setDicnum(Integer.parseInt(temp[1]));
		this.setWordTable();
		this.setDict();
		
	}
	public int getDim() {
		return dim;
	}
	public void setDim(int dim) {
		this.dim = dim;
	}
	public int getDicnum() {
		return dicnum;
	}
	public void setDicnum(int dicnum) {
		this.dicnum = dicnum;
	}
	public Table getCharTable() {
		return charTable;
	}
	public void setWordTable() throws IOException {
		this.charTable = new Table(dim);
		for(int row = 0 ; row != dim; ++row){
			String tableline = this.br.readLine();
			int linepos = 0;
			for(int col = 0 ; col != dim; ++col){
				if(tableline.charAt(linepos) == ' ') linepos += 1;
				this.charTable.set_val_by_index(row, col, 
						tableline.charAt(linepos));
				linepos += 1;
			}
		}
		
	}
	public Dictionary getDict() {
		return dict;
	}
	public void setDict() throws IOException {
		int order = 0;
		
		char before = '\0';
		dict = new Dictionary();
		for(int i = 0 ; i != this.dicnum; ++i){//dicnum만큼 단어를 받음
			String word = this.br.readLine();
			char c = word.charAt(0);
			
			if(before != c){
				before = c;
				dict.getDict().insertFront(new KeySet(word, order));
				
				/* 
				 * before = c;
				 * dict.create_newKeySet(String word);
				 */
			}
			else dict.getDict().getHead().getData().add(word,order);
			//dict.getCursor().add(tableline);
			order++;
		}
		
		
		
	}
	public void print(){
		System.out.printf("Dim : %d, DictNum : %d\n", this.getDim(), this.getDicnum());
		this.charTable.print();
		this.dict.print();
	}


}
