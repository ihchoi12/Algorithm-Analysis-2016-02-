package OutputData;

public class Point{
	private int x;
	private int y;
	public Point(){
		x = -1; y = -1;
	}
	public Point(int x, int y){
		this.x = x; this.y = y;
	}
	public void print(){
		System.out.printf("( %d , %d )", x, y);
	}
	public int getX(){return x;}
	public int getY(){return y;}
	public void setX(int x){
		this.x = x;
	}
	public void setY(int y){
		this.y = y;
	}
	public boolean is_null(){
		return x == -1;
	}
}
