package OutputData;


import List.*;
public class Output{
	private Chunk[] sol;
	private int solnum;
	public Output(int solnum){
		sol = null;
		this.solnum = solnum;
		sol = new Chunk[solnum];
		for(int i = 0 ; i != solnum; ++i)
			sol[i] = new Chunk();
	}
	public void print(){
		for(int i = 0 ; i != solnum; ++i){
			if(sol[i].is_null())System.out.println("0");
			else{
				sol[i].print();
				System.out.println();
			}
			
		}
	}
	public void putAnswer(int index, Point start, Point end){
		sol[index].setStart(start);
		
		sol[index].setEnd(end);
		
	}

}
