package OutputData;

public class 	Chunk{
	private Point start;
	private Point end;
	
	public Chunk(){
		start = new Point(-1,-1);
		end = new Point(-1,-1);
		
	}
	public void print(){
		start.print();
		end.print();
	}
	public boolean is_null(){
		return end.getX() == -1;
	}
	public void setStart(Point start){
		this.start.setX(start.getX());
		this.start.setY(start.getY());
		
	}
	public void setEnd(Point end){
		this.end.setX(end.getX());
		this.end.setY(end.getY());
		
	}
}
